from bs4 import BeautifulSoup
import requests
import re
import json
import time
import signal

class TimeoutException(Exception):
    pass

class Gryphon:
    def __init__(self):
        self.URL = "http://192.168.1.1/cgi-bin/luci"

        initialization_dict = {
            "This device": "Unknown",
            "Mac-id": "Unknown", 
            "Assigned to": "Unknown", 
            "Filter level": "Unknown", 
            "Remaining internet time": 'Unknown',
            "last time updated": 0,
            "raw time remaining": 0,
            "status": "Unknown"
        }

        with open("status.json") as status_json: # if json file doesn't have correct value (for whatever reason), update it to default values
            self.d = json.load(status_json)
            for key, value in initialization_dict.items():
                if key not in self.d.keys():
                    self.d[key] = value


        with open("status.json", 'w') as status_json:
            json.dump(self.d, status_json, indent=2)

        self.verbose_status_dict = {
            'Nominal' : {'short':'Nominal', 'long':'Nominal.'}, # short is in header window; long is in notification text
            'ConnectionError' : {'short': 'Connection error', 'long':'ConnectionError detected. Try joining WiFi again.'},
            'suspended' : {'short': 'Internet suspended', 'long' : 'Internet has been suspended.'},
            'exceeded' : {'short': 'time exceeded', 'long':"Out of internet time."},
            'Slow Connection': {'short':'Slow connection', 'long':"Slow Connection (1 second ping time exceeded)."},
            'It is bedtime': {'short':'Bedtime', 'long':"Bedtime."}
        }


 
        

    

    def slow_connection(self):
        raise TimeoutException

    def get_data(self):

        signal.signal(signal.SIGALRM, self.slow_connection) # for network timeout
        try:
            signal.alarm(3)
            self.data = requests.get(self.URL)
            signal.alarm(0)

            self.soup = BeautifulSoup(self.data.text, features="html.parser")

            self.main_text = self.soup.find("div", {"class": "text_body"}).text

            self.status = "Nominal"
            possible_bad_keywords = ['suspended', 'exceeded', 'It is bedtime']
            for keyword in possible_bad_keywords:
                if keyword in self.main_text:
                    self.status = keyword
            #print("data parsed")

        except TimeoutException: 
            self.status = 'Slow Connection'
            signal.alarm(0)

        except requests.exceptions.ConnectionError:
            self.status = 'ConnectionError'
            signal.alarm(0)

        self.d['status'] = self.status
        self.d['short_status'] = self.verbose_status_dict[self.status]['short']
        self.d['long_status'] = self.verbose_status_dict[self.status]['long']

        if self.status == "Nominal": # if gryphon page works correctly: if self.matching has length 4
            self.matching = re.findall('^([^\n]*): (.*)$', self.main_text, flags=re.MULTILINE) # use regex to format scraped data
            self.d.update(
                {tup[0] : tup[1] for tup in self.matching} # add to dictionary all files scraped from gryphon homepage
            )
            self.d['last time updated'] = time.time()
            
            
            time_left_formatted = self.d['Remaining internet time']
            time_ = re.search('\d+:\d{2}', time_left_formatted).group(0)

            self.d['Remaining internet time'] = time_ # replace some data: get rid of stuff around the HH:MM formatted time
            self.d['raw time remaining'] = self.get_time_int(time_) # and add a raw minutes integer as well
        

        with open('status.json', 'w') as status_json:
            json.dump(self.d, status_json, indent=2)



    def get_time_int(self, time_formatted):
        time_digits = time_formatted.split(":")
        try: 
            time_int = int(time_digits[0]) * 60 + int(time_digits[1]) # time remaining in minutes
            return time_int
        except ValueError: 
            pass
        

    
    

if __name__ == "__main__":
    gryphon = Gryphon()
    gryphon.get_data()