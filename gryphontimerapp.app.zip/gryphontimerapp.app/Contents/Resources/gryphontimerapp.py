import rumps; rumps.debug_mode(True)
from backend import Gryphon
import json
import re
import time
import webbrowser
import functools

__version__ = 0.1
#modify line 1307 in rumps.App, otherwise notifications don't work
class GryphonApp(rumps.App):
    def __init__(self):

        super().__init__(name='GryphonApp', icon="Griffin.png")
        self.gryphon = Gryphon()

        with open("status.json") as status_json:
            self.data = json.load(status_json) 
        
        self.my_github = "https://github.com/"

        self.menu = [
            'status',
            None,
            'time_remaining', 
            'filter_level',
            None, 
            ['Nerd stuff', 
                ['device_name', 'mac_id', 'assigned_to']
            ], 
            None,
            ['Settings', 
                [rumps.MenuItem('time_alerts', callback=self.change_time_alert_settings),
                rumps.MenuItem('alert_sounds', callback=self.toggle_alert_sounds),
                rumps.MenuItem('Test Alert', callback=self.test_alert),
                None,
                "By Jim Bradley (2435191), Python 3.8, Sept 2020.",
                f"Version {__version__}",
                None,
                rumps.MenuItem("Navigate to this project's GitHub", callback=functools.partial(webbrowser.open, self.my_github))
                
                ]
            ]
        ] 

        with open("settings.json") as settings_json:
            self.notif_sounds = json.load(settings_json)['notif_sounds']

        self.menu['Settings']['alert_sounds'].title = "Play sound when an alert pops up?"
        self.menu['Settings']['time_alerts'].title = "Configure time alert values"
  
        self.menu['Settings']['alert_sounds'].state = self.notif_sounds # checkmark
        
        self.timer = rumps.Timer(self.update_stuff, 1.25)
        self.timer.start()

        

        self.time_alert_values = []

        


        

    def update_stuff(self, _):

        self.gryphon.get_data()

        with open("status.json") as status_json:
            self.new_data = json.load(status_json)

            if self.new_data['status'] != self.data['status']:
                rumps.notification(
                        'Status alert', 
                        "Your device's status was updated.", 
                        f"Status: {self.new_data['long_status']}", 
                        data=None, 
                        sound=self.notif_sounds,
                        icon='Griffin.png')

        if self.new_data['status'] == "Nominal":
            
            self.new_raw_time = self.new_data['raw time remaining']
            self.raw_time = self.data['raw time remaining']

            if self.new_raw_time > self.raw_time:

                rumps.notification(
                        'Time alert', 
                        'Time has been added.', 
                        f"You have {self.new_data['Remaining internet time']} remaining.", 
                        data=None, 
                        sound=self.notif_sounds,
                        icon='Griffin.png'
                        )

            if self.new_data['Filter level'] != self.data['Filter level']:
                rumps.notification(
                        'Filter alert', 
                        'Your filter level has been changed. Probably mouthed off to Dad again, huh?', 
                        f"Your filter level is now {self.new_data['Filter level']}.", 
                        data=None, 
                        sound=self.notif_sounds,
                        icon='Griffin.png'
                        )

            

            # less than whatever time notifications
            for t in self.time_alert_values:
                if t == self.new_raw_time and t != self.raw_time: # last part so that it only prints when edge detected
                    #print(f"you have {self.new_data['Remaining internet time']} remaining")
                    rumps.notification(
                        'Time alert', 
                        'A time alert set in the settings panel has been tripped.', 
                        f"You have {self.new_data['Remaining internet time']} remaining.", 
                        data=None, 
                        sound=self.notif_sounds,
                        icon='Griffin.png'
                        )
                    
                    break # so that only 1 alarm is triggered

        
        # and update all the variables again
        self.data = self.new_data
            

        # update menu
    
        raw_time = self.data['last time updated']
        formatted_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(raw_time))
        if self.data['status'] != 'Nominal': # break after statuses
            self.menu['status'].title = f"{self.data['short_status']} (all other statuses last measured"
            if "formatted_time" not in self.menu.keys():
                self.menu.insert_after('status', "formatted_time")
                self.menu["formatted_time"].title = f"{formatted_time})"

        else:
            self.menu['status'].title = "Nominal"

            if "formatted_time" in self.menu.keys():
                del self.menu["formatted_time"]


        self.menu['time_remaining'].title = f"{self.data['Remaining internet time']} time remaining"
        self.menu['filter_level'].title = f"{self.data['Filter level']} filter level"
        self.menu['Nerd stuff']['device_name'].title = f"Device name: {self.data['This device']}"
        self.menu['Nerd stuff']['mac_id'].title = f"MAC ID: {self.data['Mac-id']}"
        self.menu['Nerd stuff']['assigned_to'].title = f"Assigned to {self.data['Assigned to']}"
            


    def change_time_alert_settings(self, _): # handles changing of alert values in settings panel
        with open('settings.json') as json_file:
            d = json.load(json_file)
            self.default_text = d['actualTextString']
            

        window_ = rumps.Window(
            title = "Change time settings",
            message = "Enter a comma-separated list of time values in the following format: HH:MM. You will be alerted when your remaining time equals each of these values. The values stored are persistent between app instances.",
            ok = "Submit",
            cancel = None,
            default_text = self.default_text
        )

        window_.icon = 'Griffin.png'

        self.time_alerts_settings_window = window_.run()

        response_text = self.time_alerts_settings_window.text
        d['actualTextString'] = response_text
        with open('settings.json', 'w') as json_file: # split up json workload so that text is preserved if bad syntax
            json.dump(d, json_file, indent=2)

        self.time_alert_values = [i for i in map(self.gryphon.get_time_int, 
            response_text.split(',')) if i != None]
        d['intTimeValues'] = self.time_alert_values # don't need to store these, but just in case
        
        with open('settings.json', 'w') as json_file:
            json.dump(d, json_file, indent=2)

    def toggle_alert_sounds(self, sender):
        self.notif_sounds = not self.notif_sounds
        sender.state = self.notif_sounds

        # then change notif_sounds in json file
        with open('settings.json') as settings_json:
            settings_dict = json.load(settings_json)
            settings_dict['notif_sounds'] = self.notif_sounds # just to make SURE these are the same

        with open('settings.json', 'w') as settings_json:
            json.dump(settings_dict, settings_json, indent=2)


    def test_alert(self, _):
        rumps.notification(
            'Test alert', 
            'Triggered from Settings:Test Alert', 
            f"Sound is {'on' if self.notif_sounds else 'off'}", 
            data=None, 
            sound=self.notif_sounds,
            icon='Griffin.png'
        )

        


GryphonApp().run()